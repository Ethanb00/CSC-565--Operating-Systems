Operating Systems
Shell Project
Ethan Bennett


The shell is contained in a.out.  To run the shell, run ./a.out in the terminal.  An example file is located in the folder and is called test.c and its executable is test.out.  

The shell contains the following commands:
	*exit
	*type
	*copy
	*delete

To run an executable, simply enter the full name of the file into the shell.
When running an execute on the included file, make sure to write ./test.out or the file will not be recognized by the shell.


Citations:
	Code for parsing the user input was from Dr. Black's blackboard post.
